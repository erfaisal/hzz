"""
hadhiya._messages
~~~~~~~~~~~~~~~~~

All message collections used by the hadhiya package.

Every function in the library randomly selects one of these messages.
"""

from __future__ import annotations

GOOD_MORNING = [
    "☀️ Good morning! Hope today brings you something worth smiling about.",
    "Rise, shine, and don't forget to drink water.",
    "A brand new day, a brand new opportunity.",
    "Good morning! Today is another chance to do something amazing.",
    "May your coffee be strong and your worries be small.",
    "Smile. The day just got a little brighter.",
    "Wake up. The world has been waiting for your smile.",
    "Hope today surprises you in the best possible way.",
    "Start today with kindness, especially toward yourself.",
    "Good morning! You've got this."
]

GOOD_NIGHT = [
    "🌙 Good night. Rest well.",
    "Sleep peacefully. Tomorrow can wait.",
    "You've done enough for today.",
    "Dream big. Tomorrow is another chapter.",
    "Time to recharge your superpowers.",
    "Close your eyes and let your mind rest.",
    "Good night. May tomorrow be gentle with you.",
    "The stars are working overtime tonight.",
    "Rest now. Great things need energy.",
    "Sweet dreams!"
]

COMPLIMENTS = [
    "You're genuinely easy to talk to.",
    "You somehow make ordinary conversations memorable.",
    "Your kindness doesn't go unnoticed.",
    "You're stronger than you realize.",
    "You have a calming presence.",
    "People are lucky to have you around.",
    "You notice little things. That's rare.",
    "You make the world slightly brighter just by being yourself.",
    "You have a wonderful way of making people comfortable.",
    "You deserve every reason to smile today.",
    "Your curiosity is one of your best qualities.",
    "You always seem to leave a good impression.",
    "Your smile is probably contagious.",
    "You're one of those people others remember.",
    "Keep being yourself. It's working."
]

MOTIVATION = [
    "One small step is still progress.",
    "Don't rush. Consistency beats speed.",
    "The hardest part is starting.",
    "Your future self will thank you.",
    "Keep going. You're closer than yesterday.",
    "Progress, not perfection.",
    "Everything difficult was once unfamiliar.",
    "Small improvements become big results.",
    "Believe in your ability to learn.",
    "Today's effort becomes tomorrow's confidence.",
    "You can do difficult things.",
    "Be patient with yourself.",
    "Even slow progress is progress.",
    "One page at a time.",
    "Keep showing up."
]

STUDY = [
    "📚 Focus for just 25 minutes.",
    "One chapter now saves stress later.",
    "Your future self is cheering for you.",
    "Close Instagram. Open your notes.",
    "Knowledge compounds every day.",
    "Start before you feel ready.",
    "A little studying is better than none.",
    "Don't aim for perfect. Aim for finished.",
    "Study first. Celebrate later.",
    "You've got this!"
]

BREAK = [
    "Stretch your shoulders.",
    "Look away from the screen for 20 seconds.",
    "Drink some water.",
    "Take a deep breath.",
    "Resting isn't wasting time.",
    "Walk around for two minutes.",
    "Blink. Seriously.",
    "Your brain deserves a tiny break.",
    "Come back refreshed.",
    "A short break improves focus."
]

WATER = [
    "💧 Water check!",
    "Hydration reminder!",
    "Go drink a glass of water.",
    "Future you says thanks.",
    "Stay hydrated.",
    "Your brain likes water too.",
    "Don't ignore this reminder.",
    "Water > another scroll.",
    "Just one glass.",
    "Hydration complete?"
]

TEA = [
    "☕ Tea sounds like a great idea.",
    "Everything feels easier after tea.",
    "Tea break unlocked.",
    "Hot tea. Calm mind.",
    "Go make your favorite cup.",
    "Tea time!",
    "Sip slowly.",
    "The kettle believes in you.",
    "Tea solves at least 12% of problems.",
    "Today's mood: tea."
]

SMILES = [
    "😊 Smile detected.",
    "Mission: Make someone smile.",
    "Loading happiness... Complete.",
    "You deserve to smile today.",
    "A smile looks good on everyone.",
    "Smiling is free.",
    "Here's your daily smile reminder.",
    "Smile... just because.",
    "Today's objective completed: 😊",
    "Mission accomplished."
]

FACTS = [
    "Octopuses have three hearts.",
    "Honey never spoils.",
    "Bananas are berries.",
    "Your brain uses about 20% of your body's energy.",
    "A day on Venus is longer than a year on Venus.",
    "Sharks existed before trees.",
    "The Eiffel Tower grows slightly taller in summer.",
    "There are more stars than grains of sand on Earth.",
    "The heart beats around 100,000 times every day.",
    "A smile uses fewer muscles than many people think."
]

JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "There are only 10 kinds of people: those who understand binary and those who don't.",
    "Python developers don't get bitten—they import antivenom.",
    "Debugging: removing the needles from the haystack.",
    "I would tell a UDP joke, but you might not get it.",
    "Computers make very fast mistakes.",
    "Keyboard not found. Press any key to continue.",
    "Programmers count from zero.",
    "Git happens.",
    "Have you tried turning it off and on again?"
]

FORTUNES = [
    "Today will bring an unexpected smile.",
    "Good news is closer than you think.",
    "Someone will appreciate your kindness.",
    "You'll learn something useful today.",
    "A tiny surprise is waiting.",
    "Today is a good day to begin.",
    "Luck favors those who keep trying.",
    "You'll solve something you've been stuck on.",
    "A pleasant conversation awaits.",
    "Something nice is coming."
]

SECRETS = [
    "🌸 Thank you for existing.",
    "Someone thought making this package was worth the effort.",
    "You matter more than you know.",
    "Never underestimate the impact of your kindness.",
    "This message exists just to make you smile.",
    "You found an easter egg!",
    "You're appreciated.",
    "Hope this made your day a little better.",
    "Keep being yourself.",
    "Mission accomplished? 😊"
]

ASCII_HEART = r"""
      *****       *****
   *********** ***********
 ***********************
***************************
 *************************
   *********************
      ***************
         *********
           *****
             *
"""

ASCII_FLOWER = r"""
          .
       .-^^-.
    .-'    '-.
   /  .--.    \
  |  (    )    |
   \  '--'    /
    '-.___.-'
        ||
      \\||//
       \||/
        ||
"""

ASCII_CAT = r"""
 /\_/\\
( o.o )
 > ^ <
"""