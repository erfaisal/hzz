"""
hadhiya._ascii
~~~~~~~~~~~~~~

Beautiful ASCII/Unicode art used by the hadhiya package.

Every function returns a string.
Nothing is printed automatically so users can either:

    print(hadhiya.heart())

or

    print(hadhiya.flower())

All artwork is original or simple geometric text art.
"""

from __future__ import annotations

import random

# ---------------------------------------------------------------------
# Hearts
# ---------------------------------------------------------------------


def heart() -> str:
    return r"""
      ******       ******
   *********** ***********
 ***************************
*****************************
*****************************
 ***************************
   ***********************
      *****************
         ***********
            *****
              *
"""


def tiny_heart() -> str:
    return r"""
 ❤
"""


def double_heart() -> str:
    return r"""
 ❤   ❤
"""


# ---------------------------------------------------------------------
# Flowers
# ---------------------------------------------------------------------


def flower() -> str:
    return r"""
          .
      .-^^^^-.
   .-'      '-.
  /   .--.     \
 |   (    )     |
  \   '--'     /
   '-._____.-'
        ||
      \\||//
       \||/
        ||
        ||
"""


def rose() -> str:
    return r"""
          @@@
       @@@@@@@
      @@@@@@@@@
        ||||
      \||||||/
       \||||/
        ||||
        ||||
        ||||
"""


def tulip() -> str:
    return r"""
      .-.
     /   \
    |     |
     \   /
      \_/
       |
      / \
     /___\
"""


def sunflower() -> str:
    return r"""
      \ | /
    -- 🌻 --
      / | \
        |
        |
       / \
"""


# ---------------------------------------------------------------------
# Stars
# ---------------------------------------------------------------------


def star() -> str:
    return r"""
     ★
"""


def stars() -> str:
    return r"""
★   ☆   ★   ☆   ★
"""


def night() -> str:
    return r"""
      ✦       ★
  ★         ✦
        ☾
★               ★
"""


# ---------------------------------------------------------------------
# Nature
# ---------------------------------------------------------------------


def tree() -> str:
    return r"""
        /\
       /**\
      /****\
     /******\
        ||
        ||
"""


def cloud() -> str:
    return r"""
      .--.
   .-(    ).
  (___.__)__)
"""


def sun() -> str:
    return r"""
      \ | /
    -- ☀ --
      / | \
"""


def rainbow() -> str:
    return r"""
🌈🌈🌈🌈🌈🌈🌈
"""


# ---------------------------------------------------------------------
# Cute Animals
# ---------------------------------------------------------------------


def cat() -> str:
    return r"""
 /\_/\\
( o.o )
 > ^ <
"""


def happy_cat() -> str:
    return r"""
 /\_/\\
( ^.^ )
 > ^ <
"""


def bunny() -> str:
    return r"""
 (\_/)
 (•.•)
/>🥕
"""


def bear() -> str:
    return r"""
 ʕ•ᴥ•ʔ
"""


def penguin() -> str:
    return r"""
   _~_
  (o o)
 /  V  \
/(  _  )\
  ^^ ^^
"""


# ---------------------------------------------------------------------
# Coffee / Tea
# ---------------------------------------------------------------------


def coffee() -> str:
    return r"""
   (
    )     (
     _______)
  .-'-------.
 ( C| COFFEE|)
  '-._____.-'
"""


def tea() -> str:
    return r"""
     (
      )
   .-'''-.
  |  TEA |
  |      |
   '----'
"""


# ---------------------------------------------------------------------
# Smiley Faces
# ---------------------------------------------------------------------


def smile() -> str:
    return r"""
😊
"""


def happy() -> str:
    return r"""
(◕‿◕)
"""


def excited() -> str:
    return r"""
٩(◕‿◕)۶
"""


def shrug() -> str:
    return r"""
¯\_(ツ)_/¯
"""


# ---------------------------------------------------------------------
# Friendship
# ---------------------------------------------------------------------


def handshake() -> str:
    return r"""
🤝
"""


def hug() -> str:
    return r"""
⊂(･ω･*⊂)
"""


# ---------------------------------------------------------------------
# Decorations
# ---------------------------------------------------------------------


def divider(width: int = 40) -> str:
    return "─" * width


def dotted(width: int = 40) -> str:
    return "·" * width


def stars_divider(width: int = 20) -> str:
    return ("★" * width)


def hearts_divider(width: int = 20) -> str:
    return ("❤" * width)


# ---------------------------------------------------------------------
# Loading Frames
# ---------------------------------------------------------------------


LOADING = [
    "[          ]",
    "[█         ]",
    "[██        ]",
    "[███       ]",
    "[████      ]",
    "[█████     ]",
    "[██████    ]",
    "[███████   ]",
    "[████████  ]",
    "[█████████ ]",
    "[██████████]",
]


SPINNER = [
    "|",
    "/",
    "-",
    "\\",
]


# ---------------------------------------------------------------------
# Random Art
# ---------------------------------------------------------------------


_RANDOM_ART = [
    heart,
    flower,
    rose,
    sunflower,
    tulip,
    star,
    stars,
    rainbow,
    tree,
    sun,
    cloud,
    cat,
    happy_cat,
    bunny,
    bear,
    penguin,
    coffee,
    tea,
]


def random_art() -> str:
    """Return a random ASCII/Unicode artwork."""
    return random.choice(_RANDOM_ART)()


# ---------------------------------------------------------------------
# Package Banner
# ---------------------------------------------------------------------


def banner() -> str:
    return r"""
██╗  ██╗ █████╗ ██████╗ ██╗  ██╗██╗██╗   ██╗ █████╗
██║  ██║██╔══██╗██╔══██╗██║  ██║██║╚██╗ ██╔╝██╔══██╗
███████║███████║██║  ██║███████║██║ ╚████╔╝ ███████║
██╔══██║██╔══██║██║  ██║██╔══██║██║  ╚██╔╝  ██╔══██║
██║  ██║██║  ██║██████╔╝██║  ██║██║   ██║   ██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚═╝   ╚═╝   ╚═╝  ╚═╝

            A tiny package that spreads smiles 🌸
"""


__all__ = [
    "banner",
    "bear",
    "bunny",
    "cat",
    "cloud",
    "coffee",
    "divider",
    "dotted",
    "double_heart",
    "excited",
    "flower",
    "happy",
    "happy_cat",
    "heart",
    "hearts_divider",
    "hug",
    "handshake",
    "LOADING",
    "night",
    "penguin",
    "rainbow",
    "random_art",
    "rose",
    "shrug",
    "smile",
    "SPINNER",
    "star",
    "stars",
    "stars_divider",
    "sun",
    "sunflower",
    "tea",
    "tiny_heart",
    "tree",
    "tulip",
]