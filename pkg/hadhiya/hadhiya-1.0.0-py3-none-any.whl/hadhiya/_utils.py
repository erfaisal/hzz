"""
hadhiya._utils
~~~~~~~~~~~~~~

Internal helper utilities used throughout the hadhiya package.

These functions are not intended to be imported directly by users.
"""

from __future__ import annotations

import random
import shutil
import sys
import textwrap
import time
from typing import Iterable, Sequence, TypeVar

T = TypeVar("T")


# ----------------------------------------------------------------------
# Random Helpers
# ----------------------------------------------------------------------

def choose(messages: Sequence[T]) -> T:
    """
    Return a random item from a sequence.

    Raises
    ------
    ValueError
        If the sequence is empty.
    """
    if not messages:
        raise ValueError("Message collection cannot be empty.")
    return random.choice(messages)


def chance(percent: float) -> bool:
    """
    Return True with the given probability.

    Example
    -------
    >>> chance(25)
    False
    """
    if percent <= 0:
        return False
    if percent >= 100:
        return True

    return random.random() < percent / 100


# ----------------------------------------------------------------------
# Printing Helpers
# ----------------------------------------------------------------------

def line(char: str = "─", width: int | None = None) -> None:
    """
    Print a horizontal divider.
    """
    width = width or shutil.get_terminal_size((80, 20)).columns
    print(char * width)


def center(text: str) -> None:
    """
    Print centered text.
    """
    width = shutil.get_terminal_size((80, 20)).columns
    print(text.center(width))


def boxed(text: str) -> None:
    """
    Print text inside a simple Unicode box.
    """
    wrapped = textwrap.wrap(text, width=60)

    width = max(len(i) for i in wrapped)

    print("┌" + "─" * (width + 2) + "┐")

    for item in wrapped:
        print(f"│ {item.ljust(width)} │")

    print("└" + "─" * (width + 2) + "┘")


def pretty(text: str) -> None:
    """
    Print wrapped text.
    """
    print(textwrap.fill(text, width=70))


# ----------------------------------------------------------------------
# Loading Animation
# ----------------------------------------------------------------------

def loading(
    text: str = "Loading",
    seconds: float = 2.0,
    interval: float = 0.25,
) -> None:
    """
    Display a simple loading animation.

    Example
    -------
    >>> loading("Preparing")
    """

    end = time.time() + seconds

    while time.time() < end:
        for dots in ("", ".", "..", "..."):
            print(f"\r{text}{dots}   ", end="", flush=True)
            time.sleep(interval)

            if time.time() >= end:
                break

    print("\r" + " " * 40, end="\r")


# ----------------------------------------------------------------------
# Progress Bar
# ----------------------------------------------------------------------

def progress(
    total: int = 20,
    delay: float = 0.05,
) -> None:
    """
    Display a progress bar.
    """

    for i in range(total + 1):
        done = "█" * i
        left = "░" * (total - i)

        percent = int(i / total * 100)

        print(
            f"\r[{done}{left}] {percent:3d}%",
            end="",
            flush=True,
        )

        time.sleep(delay)

    print()


# ----------------------------------------------------------------------
# Typewriter Effect
# ----------------------------------------------------------------------

def typewrite(
    text: str,
    delay: float = 0.02,
) -> None:
    """
    Print text one character at a time.
    """

    for character in text:
        print(character, end="", flush=True)
        time.sleep(delay)

    print()


# ----------------------------------------------------------------------
# Pause
# ----------------------------------------------------------------------

def pause(seconds: float = 1.0) -> None:
    """
    Sleep for the given number of seconds.
    """
    time.sleep(seconds)


# ----------------------------------------------------------------------
# Terminal Size
# ----------------------------------------------------------------------

def terminal_width(default: int = 80) -> int:
    """
    Return terminal width.
    """
    return shutil.get_terminal_size((default, 20)).columns


# ----------------------------------------------------------------------
# Banner
# ----------------------------------------------------------------------

def banner(title: str) -> None:
    """
    Print a nice section banner.
    """

    width = terminal_width()

    print()
    print("=" * width)
    print(title.center(width))
    print("=" * width)
    print()


# ----------------------------------------------------------------------
# Emoji Helpers
# ----------------------------------------------------------------------

def sparkle(text: str) -> str:
    """
    Wrap text with sparkles.
    """
    return f"✨ {text} ✨"


def heart(text: str) -> str:
    """
    Wrap text with hearts.
    """
    return f"❤️ {text} ❤️"


def flower(text: str) -> str:
    """
    Wrap text with flowers.
    """
    return f"🌸 {text} 🌸"


# ----------------------------------------------------------------------
# Random Numbers
# ----------------------------------------------------------------------

def coin_flip() -> str:
    """
    Flip a coin.
    """
    return random.choice(("Heads", "Tails"))


def roll_dice(sides: int = 6) -> int:
    """
    Roll a dice.

    Parameters
    ----------
    sides : int
        Number of sides.

    Returns
    -------
    int
    """

    if sides < 2:
        raise ValueError("Dice must have at least 2 sides.")

    return random.randint(1, sides)


# ----------------------------------------------------------------------
# Exit Helper
# ----------------------------------------------------------------------

def goodbye() -> None:
    """
    Print a farewell message.
    """
    print("Thank you for using hadhiya 🌸")


__all__ = [
    "banner",
    "boxed",
    "center",
    "chance",
    "choose",
    "coin_flip",
    "flower",
    "goodbye",
    "heart",
    "line",
    "loading",
    "pause",
    "pretty",
    "progress",
    "roll_dice",
    "sparkle",
    "terminal_width",
    "typewrite",
]