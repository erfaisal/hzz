"""
hadhiya
========

A tiny Python package created to spread smiles, positivity, and friendship.

Example
-------
>>> import hadhiya as h
>>> h.good_morning()
>>> h.compliment()
>>> h.smile()
"""

from ._ascii import *
from ._messages import *
from ._utils import *

__title__ = "hadhiya"
__author__ = "Faisal Muzaffar"
__license__ = "MIT"
__version__ = "1.0.0"
__description__ = "A tiny Python package that spreads smiles and positivity."


# ---------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------

import random

from . import _ascii
from . import _messages
from ._utils import choose


def good_morning() -> None:
    """Print a random good morning message."""
    print(choose(_messages.GOOD_MORNING))


def good_night() -> None:
    """Print a random good night message."""
    print(choose(_messages.GOOD_NIGHT))


def smile() -> None:
    """Print a cheerful message."""
    print(choose(_messages.SMILES))


def compliment() -> None:
    """Print a wholesome compliment."""
    print(choose(_messages.COMPLIMENTS))


def motivate() -> None:
    """Print a motivational quote."""
    print(choose(_messages.MOTIVATION))


def study() -> None:
    """Print a study reminder."""
    print(choose(_messages.STUDY))


def take_break() -> None:
    """Print a break reminder."""
    print(choose(_messages.BREAK))


def drink_water() -> None:
    """Print a hydration reminder."""
    print(choose(_messages.WATER))


def tea() -> None:
    """Print a tea reminder."""
    print(choose(_messages.TEA))


def random_fact() -> None:
    """Print a random fact."""
    print(choose(_messages.FACTS))


def joke() -> None:
    """Print a random programming joke."""
    print(choose(_messages.JOKES))


def fortune() -> None:
    """Print a random fortune."""
    print(choose(_messages.FORTUNES))


def secret() -> None:
    """Print a hidden friendly message."""
    print(choose(_messages.SECRETS))


# ---------------------------------------------------------------------
# ASCII Art
# ---------------------------------------------------------------------

def heart() -> None:
    """Print a heart."""
    print(_ascii.heart())


def flower() -> None:
    """Print a flower."""
    print(_ascii.flower())


def rose() -> None:
    """Print a rose."""
    print(_ascii.rose())


def sunflower() -> None:
    """Print a sunflower."""
    print(_ascii.sunflower())


def cat() -> None:
    """Print a cat."""
    print(_ascii.cat())


def bunny() -> None:
    """Print a bunny."""
    print(_ascii.bunny())


def coffee() -> None:
    """Print coffee art."""
    print(_ascii.coffee())


def random_art() -> None:
    """Print a random ASCII artwork."""
    print(_ascii.random_art())


# ---------------------------------------------------------------------
# Information
# ---------------------------------------------------------------------

def version() -> str:
    """Return the package version."""
    return __version__


def about() -> None:
    """Display package information."""
    print(
f"""
hadhiya {__version__}

Made with Python ❤️

A tiny package created to spread smiles,
kindness and positive vibes.

Author : {__author__}
License: {__license__}
"""
    )


# ---------------------------------------------------------------------
# Surprise!
# ---------------------------------------------------------------------

def surprise() -> None:
    """Print a random surprise."""

    options = [
        compliment,
        motivate,
        smile,
        random_fact,
        joke,
        fortune,
        heart,
        flower,
        random_art,
    ]

    random.choice(options)()


# ---------------------------------------------------------------------
# Package Exports
# ---------------------------------------------------------------------

__all__ = [
    "__version__",
    "__author__",
    "__license__",
    "__title__",
    "__description__",
    "about",
    "bunny",
    "cat",
    "coffee",
    "compliment",
    "drink_water",
    "flower",
    "fortune",
    "good_morning",
    "good_night",
    "heart",
    "joke",
    "motivate",
    "random_art",
    "random_fact",
    "rose",
    "secret",
    "smile",
    "study",
    "sunflower",
    "surprise",
    "take_break",
    "tea",
    "version",
]