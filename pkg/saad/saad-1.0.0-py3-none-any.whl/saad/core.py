def qzz():
    print("Ahmad Saad")