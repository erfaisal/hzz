def qzz():
    print("Aligarh Muslim University\nby Faisal Muzaffar")