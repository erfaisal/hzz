def qzz():
    print("CupX Corporation")