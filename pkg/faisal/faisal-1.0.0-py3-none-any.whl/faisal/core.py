def qzz():
    print("Faisal Muzaffar")